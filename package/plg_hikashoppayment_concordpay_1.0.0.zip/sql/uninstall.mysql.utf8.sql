DELETE FROM `#__extensions` WHERE `element` = 'concordpay';
DELETE FROM `#__hikashop_payment` WHERE `payment_type` = 'concordpay';